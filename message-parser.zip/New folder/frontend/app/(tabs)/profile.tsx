import React, { useState, useEffect } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  View,
  StyleSheet,
  Platform,
  Image,
  ScrollView,
  ActivityIndicator
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { useAuth } from '../../context/AuthContext';
import { useRouter } from 'expo-router'; // Import useRouter for navigation
import Toast from 'react-native-toast-message'; // Import Toast
import { Camera } from 'expo-camera'; // Import Camera

const Profile = () => {
  const { user, updateUserProfile, logoutUser } = useAuth();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false); // Added loading state
  const [activeTab, setActiveTab] = useState('profile');
  const [hasPermission, setHasPermission] = useState(false); // Camera permission state
  const [cameraVisible, setCameraVisible] = useState(false); // Whether to show the camera or not
  const [cameraRef, setCameraRef] = useState(null); // Camera reference
  const router = useRouter(); // Initialize the router to navigate after logout

  useEffect(() => {
    if (user) {
      setUsername(user.username);
      setEmail(user.email);
    }
    
    // Request camera permission when the component mounts
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, [user]);

  const handleUpdateProfile = async () => {
    if (!username || !email) {
      setError('Please fill out all fields.');
      return;
    }

    setIsLoading(true); // Set loading to true when starting the update process

    try {
      await updateUserProfile(username, email);
      setError(null); // Reset error on successful update
      Toast.show({
        type: 'success',
        position: 'top',
        text1: 'Profile Updated',
        text2: 'Your profile has been updated successfully.',
        visibilityTime: 3000,
        autoHide: true,
      });
    } catch (error) {
      console.error('Error updating profile:', error);
      setError('Failed to update profile. Please try again later.');
      Toast.show({
        type: 'error',
        position: 'top',
        text1: 'Update Failed',
        text2: 'There was an issue updating your profile. Please try again.',
        visibilityTime: 3000,
        autoHide: true,
      });
    } finally {
      setIsLoading(false); // Set loading to false after update attempt (success or failure)
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      router.push('/login'); // Navigate to the login screen after logout
      Toast.show({
        type: 'success',
        position: 'top',
        text1: 'Logged Out',
        text2: 'You have been logged out successfully.',
        visibilityTime: 3000,
        autoHide: true,
      });
    } catch (error) {
      console.error('Error logging out:', error);
      Toast.show({
        type: 'error',
        position: 'top',
        text1: 'Logout Failed',
        text2: 'There was an issue logging you out. Please try again.',
        visibilityTime: 3000,
        autoHide: true,
      });
    }
  };

  const handleCapture = async () => {
    if (cameraRef) {
      const photo = await cameraRef.takePictureAsync();
      console.log('Captured photo: ', photo.uri);
      // Here you can save or upload the photo
      setCameraVisible(false); // Close the camera after capturing
    }
  };

  const handleOpenCamera = () => {
    setCameraVisible(true);
  };

  if (!user) {
    return (
      <View style={styles.container}>
        <LinearGradient
          colors={['#4A00E0', '#8E2DE2']}
          style={styles.gradientContainer}
        >
          <Text style={styles.message}>Please log in to view your profile</Text>
          <TouchableOpacity
            style={styles.loginButton}
            onPress={() => router.push('/login')}
          >
            <Text style={styles.loginButtonText}>Go to Login</Text>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient
        colors={['#4A00E0', '#8E2DE2']}
        style={styles.header}
      >
        <View style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            <Image
              source={{ uri: user.avatar || 'https://via.placeholder.com/150' }}
              style={styles.avatar}
            />
            <TouchableOpacity style={styles.editAvatarButton} onPress={handleOpenCamera}>
              <MaterialIcons name="camera-alt" size={20} color="#fff" />
            </TouchableOpacity>
          </View>
          <Text style={styles.welcomeText}>Welcome, {username}!</Text>
        </View>
      </LinearGradient>

      {cameraVisible && hasPermission && (
        <View style={styles.cameraContainer}>
          <Camera style={styles.camera} ref={setCameraRef}>
            <View style={styles.cameraButtonContainer}>
              <TouchableOpacity style={styles.captureButton} onPress={handleCapture}>
                <MaterialIcons name="camera" size={30} color="#fff" />
              </TouchableOpacity>
            </View>``
          </Camera>
        </View>
      )}

      {!cameraVisible && (
        <View style={styles.contentContainer}>
          <View style={styles.tabContainer}>
            <TouchableOpacity
              style={[styles.tab, activeTab === 'profile' && styles.activeTab]}
              onPress={() => setActiveTab('profile')}
            >
              <MaterialIcons
                name="person"
                size={24}
                color={activeTab === 'profile' ? '#4A00E0' : '#666'}
              />
              <Text style={[styles.tabText, activeTab === 'profile' && styles.activeTabText]}>
                Profile
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.tab, activeTab === 'settings' && styles.activeTab]}
              onPress={() => setActiveTab('settings')}
            >
              <MaterialIcons
                name="settings"
                size={24}
                color={activeTab === 'settings' ? '#4A00E0' : '#666'}
              />
              <Text style={[styles.tabText, activeTab === 'settings' && styles.activeTabText]}>
                Settings
              </Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.formContainer}>
            {error && (
              <View style={styles.errorContainer}>
                <MaterialIcons name="error" size={24} color="#FF3B30" />
                <Text style={styles.errorText}>{error}</Text>
              </View>
            )}

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Username</Text>
              <View style={styles.inputContainer}>
                <MaterialIcons name="person" size={24} color="#666" />
                <TextInput
                  style={styles.input}
                  placeholder="Enter username"
                  value={username}
                  onChangeText={setUsername}
                  placeholderTextColor="#666"
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email</Text>
              <View style={styles.inputContainer}>
                <MaterialIcons name="email" size={24} color="#666" />
                <TextInput
                  style={styles.input}
                  placeholder="Enter email"
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  placeholderTextColor="#666"
                />
              </View>
            </View>

            <TouchableOpacity
              style={styles.updateButton}
              onPress={handleUpdateProfile}
              disabled={isLoading}
            >
              <LinearGradient
                colors={['#8E2DE2', '#4A00E0']}
                style={styles.buttonGradient}
              >
                {isLoading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    <Text style={styles.buttonText}>Update Profile</Text>
                    <MaterialIcons name="arrow-forward" size={24} color="#fff" />
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.logoutButton}
              onPress={handleLogout}
            >
              <MaterialIcons name="logout" size={24} color="#FF3B30" />
              <Text style={styles.logoutText}>Log Out</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f6f8',
  },
  header: {
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 30,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  profileHeader: {
    alignItems: 'center',
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 15,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 3,
    borderColor: '#fff',
  },
  editAvatarButton: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    backgroundColor: '#4A00E0',
    padding: 8,
    borderRadius: 20,
    borderWidth: 3,
    borderColor: '#fff',
  },
  welcomeText: {
    fontSize: 24,
    color: '#fff',
    fontWeight: 'bold',
  },
  contentContainer: {
    flex: 1,
    marginTop: -20,
    backgroundColor: '#f4f6f8',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },
  tabContainer: {
    flexDirection: 'row',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 15,
    margin: 20,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
    borderRadius: 10,
  },
  activeTab: {
    backgroundColor: '#f0e7ff',
  },
  tabText: {
    marginLeft: 8,
    fontSize: 16,
    color: '#666',
  },
  activeTabText: {
    color: '#4A00E0',
    fontWeight: '600',
  },
  formContainer: {
    padding: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
    marginLeft: 4,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 15,
    height: 55,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: '#333',
  },
  updateButton: {
    marginTop: 20,
    borderRadius: 12,
    overflow: 'hidden',
  },
  buttonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
    marginRight: 8,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 30,
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FF3B30',
  },
  logoutText: {
    color: '#FF3B30',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFE5E5',
    padding: 15,
    borderRadius: 12,
    marginBottom: 20,
  },
  errorText: {
    color: '#FF3B30',
    marginLeft: 8,
    flex: 1,
  },
  gradientContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  message: {
    fontSize: 20,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 20,
  },
  loginButton: {
    backgroundColor: '#fff',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 25,
  },
  loginButtonText: {
    color: '#4A00E0',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default Profile;
