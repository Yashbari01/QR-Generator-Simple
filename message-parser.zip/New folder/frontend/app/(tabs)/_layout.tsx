// app/_layout.tsx or App.tsx
import React from 'react';
import { Tabs } from 'expo-router';
import { AuthProvider } from '../../context/AuthContext';
import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, useWindowDimensions } from 'react-native';
import Toast from 'react-native-toast-message';  // Import Toast

export default function TabLayout() {
  const { width } = useWindowDimensions();

  return (
    <AuthProvider>
      <Tabs>
        {/* Home Tab */}
        <Tabs.Screen
          name="home"
          options={{
            title: 'Home',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="home" size={size} color={color} />
            ),
            tabBarStyle: [styles.tabBarStyle, { height: width > 400 ? 70 : 60 }],
            tabBarActiveTintColor: '#6200ee',
            tabBarInactiveTintColor: '#bdbdbd',
          }}
        />
        
        {/* Login Tab */}
        <Tabs.Screen
          name="login"
          options={{
            title: 'Login',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="log-in" size={size} color={color} />
            ),
            tabBarStyle: [styles.tabBarStyle, { height: width > 400 ? 70 : 60 }],
            tabBarActiveTintColor: '#6200ee',
            tabBarInactiveTintColor: '#bdbdbd',
          }}
        />
        
        {/* Register Tab */}
        <Tabs.Screen
          name="register"
          options={{
            title: 'Register',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="person-add" size={size} color={color} />
            ),
            tabBarStyle: [styles.tabBarStyle, { height: width > 400 ? 70 : 60 }],
            tabBarActiveTintColor: '#6200ee',
            tabBarInactiveTintColor: '#bdbdbd',
          }}
        />
        
        {/* Profile Tab */}
        <Tabs.Screen
          name="profile"
          options={{
            title: 'Profile',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="person" size={size} color={color} />
            ),
            tabBarStyle: [styles.tabBarStyle, { height: width > 400 ? 70 : 60 }],
            tabBarActiveTintColor: '#6200ee',
            tabBarInactiveTintColor: '#bdbdbd',
          }}
        />
      </Tabs>

      {/* Add the Toast component to show notifications */}
      <Toast />
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  tabBarStyle: {
    backgroundColor: '#f4f6f8',
    paddingBottom: 5,
    borderTopWidth: 0,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: -4 },
    shadowRadius: 4,
    elevation: 8,
  },
});

