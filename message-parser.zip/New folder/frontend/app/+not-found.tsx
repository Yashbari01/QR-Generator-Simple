import { Link, Stack } from 'expo-router';
import React from 'react';
import { StyleSheet, View, Text, useWindowDimensions, TouchableOpacity } from 'react-native';

import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';

export default function NotFoundScreen() {
  const { width, height } = useWindowDimensions(); // Get window dimensions for responsiveness
  
  return (
    <>
      <Stack.Screen options={{ title: 'Oops!' }} />
      <ThemedView style={[styles.container, { padding: width > 400 ? 20 : 15 }]}>
        <ThemedText
          type="title"
          style={[styles.heading, { fontSize: width > 400 ? 30 : 24, lineHeight: width > 400 ? 36 : 30 }]}
        >
          Oops! This screen doesn't exist.
        </ThemedText>

        <ThemedText
          type="body"
          style={[styles.description, { fontSize: width > 400 ? 18 : 16 }]}
        >
          The page you're looking for is not available. You can go back to the home screen.
        </ThemedText>

        <Link href="/home" style={[styles.link, { paddingVertical: height > 600 ? 15 : 12 }]}>
          <ThemedText type="link" style={[styles.linkText, { fontSize: width > 400 ? 16 : 14 }]}>
            Go to Home Screen
          </ThemedText>
        </Link>
        
        {/* <TouchableOpacity onPress={() => console.log('Report this issue')} style={styles.reportButton}>
          <ThemedText type="link" style={[styles.linkText, { fontSize: width > 400 ? 16 : 14 }]}>
            Report this issue
          </ThemedText>
        </TouchableOpacity> */}
      </ThemedView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f4f6f8', // Light background for all devices
    paddingHorizontal: 20,
  },
  heading: {
    fontWeight: 'bold',
    color: '#6200ee', // Purple color for the title
    textAlign: 'center',
    marginBottom: 20,
  },
  description: {
    textAlign: 'center',
    color: '#333', // Dark text color for better readability
    marginBottom: 30,
    fontWeight: '300', // Lighter font weight for the description
    marginHorizontal: 30, // Add some horizontal space on larger screens
  },
  link: {
    backgroundColor: '#6200ee', // Purple background for link
    borderRadius: 8,
    paddingHorizontal: 20,
    marginTop: 15,
    marginBottom: 10,
  },
  linkText: {
    color: '#fff', // White text for links
    paddingVertical: 12,
    textAlign: 'center',
  },
  reportButton: {
    marginTop: 20,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#6200ee',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginBottom: 20,
  },
});
