import React, { createContext, useContext, useState, ReactNode } from 'react';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';  // Import AsyncStorage

// Define types for user and context state
interface User {
  username: string;
  email: string;
}

interface AuthContextType {
  user: User | null;
  loginUser: (email: string, password: string) => Promise<void>;
  logoutUser: () => void;
  registerUser: (username: string, email: string, password: string) => Promise<void>;
  updateUserProfile: (username: string, email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// AuthProvider component
export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  // Login user
  const loginUser = async (email: string, password: string) => {
    try {
      const response = await axios.post(
        'http://192.168.1.14:5000/api/auth/login',
        { email, password }
      );
      setUser(response.data.user);
      
      // Use AsyncStorage to store token and user data
      await AsyncStorage.setItem('token', response.data.token);  // Store token
      await AsyncStorage.setItem('user', JSON.stringify(response.data.user));  // Store user data as a string
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  // Register user
  const registerUser = async (username: string, email: string, password: string) => {
    try {
      const response = await axios.post(
        'http://192.168.1.14:5000/api/auth/register',
        { username, email, password }
      );
      setUser(response.data.user);
    } catch (error) {
      console.error('Error registering:', error);
    }
  };

  // Logout user
  const logoutUser = async () => {
    setUser(null);
    // Remove the token and user data from AsyncStorage when logging out
    await AsyncStorage.removeItem('token');
    await AsyncStorage.removeItem('user');
  };

  // Update user profile
  const updateUserProfile = async (username: string, email: string) => {
    const token = await AsyncStorage.getItem('token');
    if (!token) {
      throw new Error('No token found, please log in first.');
    }

    try {
      const response = await axios.put(
        'http://192.168.1.14:5000/api/auth/profile',
        { username, email },
        {
          headers: {
            Authorization: `Bearer ${token}`,  // Send token in Authorization header
          },
        }
      );
      setUser(response.data); // Update the user state with the updated profile data
    } catch (error) {
      console.error('Error updating profile:', error);
      throw new Error('Failed to update profile');
    }
  };

  return (
    <AuthContext.Provider value={{ user, loginUser, logoutUser, registerUser, updateUserProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

// Hook to use auth context
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};


// // context/AuthContext.tsx
// import React, { createContext, useContext, useState, ReactNode } from 'react';
// import axios from 'axios';

// // Define types for user and context state
// interface User {
//   username: string;
//   email: string;
// }

// interface AuthContextType {
//   user: User | null;
//   loginUser: (email: string, password: string) => Promise<void>;
//   logoutUser: () => void;
//   registerUser: (username: string, email: string, password: string) => Promise<void>;
//   updateUserProfile: (username: string, email: string) => Promise<void>;
// }

// const AuthContext = createContext<AuthContextType | undefined>(undefined);

// // AuthProvider component
// export const AuthProvider = ({ children }: { children: ReactNode }) => {
//   const [user, setUser] = useState<User | null>(null);

//   // Login user
//   const loginUser = async (email: string, password: string) => {
//     try {
//       const response = await axios.post(
//         // 'http://localhost:5000/api/auth/login', 
//         'http://192.168.1.14:5000/api/auth/login', 
//         { email, password });
//       // Set user with complete user data from response
//       setUser(response.data.user);
//       // You might want to store the token as well for further use (e.g., for authentication)
//       localStorage.setItem('token', response.data.token);  // Or AsyncStorage in React Native
//       localStorage.setItem('user', response.data.user);  // Or AsyncStorage in React Native
//     } catch (error) {
//       console.error('Error logging in:', error);
//     }
//   };
  

//   // Register user
//   const registerUser = async (username: string, email: string, password: string) => {
//     try {
//       const response = await axios.post(
//         // 'http://localhost:5000/api/auth/register',
//         'http://192.168.1.14:5000/api/auth/register',
//          { username, email, password });
//       setUser(response.data.user);
//     } catch (error) {
//       console.error('Error registering:', error);
//     }
//   };

//   // Logout user
//   const logoutUser = () => {
//     setUser(null);
//   };

//   // Update user profile
//   const updateUserProfile = async (username: string, email: string) => {
//     const token = localStorage.getItem('token');
//     if (!token) {
//       throw new Error('No token found, please log in first.');
//     }

//     try {
//       const response = await axios.put(
//         // 'http://localhost:5000/api/auth/profile',
//         'http://192.168.1.14:5000/api/auth/profile',
//         { username, email },
//         {
//           headers: {
//             Authorization: `Bearer ${token}`,  // Send token in Authorization header
//           },
//         }
//       );
//       setUser(response.data); // Update the user state with the updated profile data
//     } catch (error) {
//       console.error('Error updating profile:', error);
//       throw new Error('Failed to update profile');
//     }
//   };

//   return (
//     <AuthContext.Provider value={{ user, loginUser, logoutUser, registerUser, updateUserProfile }}>
//       {children}
//     </AuthContext.Provider>
//   );
// };

// // Hook to use auth context
// export const useAuth = (): AuthContextType => {
//   const context = useContext(AuthContext);
//   if (!context) {
//     throw new Error('useAuth must be used within an AuthProvider');
//   }
//   return context;
// };
