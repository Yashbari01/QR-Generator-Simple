// routes/userRoutes.js

const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const auth = require('../middleware/auth');

// User Routes
router.post('/register', userController.registerUser); // User Registration
router.post('/login', userController.loginUser); // User Login
router.get('/profile', auth, userController.getUserProfile); // Get user profile (Authenticated)

module.exports = router;
