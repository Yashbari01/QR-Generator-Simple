// routes/subscriptionRoutes.js

const express = require('express');
const router = express.Router();
const subscriptionController = require('../controllers/subscriptionController');
const auth = require('../middleware/auth');

// Subscription Routes
router.post('/upgrade', auth, subscriptionController.updateSubscription); // Upgrade to premium
router.get('/status', auth, subscriptionController.getUserSubscription); // Check subscription status

module.exports = router;
