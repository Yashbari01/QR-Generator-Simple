// routes/songRoutes.js

const express = require('express');
const router = express.Router();
const songController = require('../controllers/songController');
const auth = require('../middleware/auth');
const rateLimit = require('../middleware/rateLimit');

// Song Routes
router.post('/create', auth, songController.createSong); // Create new song (Authenticated)
router.get('/', songController.getAllSongs); // Get all songs
router.get('/', songController.searchForSongs); // Get song by ID
// router.post('/:id/play', rateLimit, songController.incrementPlayCount); // Increment play count (Rate limit)
// router.get('/:id/comments', songController.getSongComments); // Get song comments
router.get('/comments', songController.getSongRecommendations); // Get song comments

module.exports = router;
