const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notificationController');
const auth = require('../middleware/auth');

// Notification Routes
router.get('/', auth, notificationController.getUserNotifications); // Get user notifications

module.exports = router;
