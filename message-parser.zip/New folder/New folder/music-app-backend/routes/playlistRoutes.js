// routes/playlistRoutes.js

const express = require('express');
const router = express.Router();
const playlistController = require('../controllers/playlistController');
const auth = require('../middleware/auth');

// Playlist Routes
router.post('/create', auth, playlistController.createPlaylist); // Create a new playlist
router.get('/', auth, playlistController.getUserPlaylists); // Get user playlists
// router.post('/:id/add', auth, playlistController.addSongToPlaylist); // Add song to playlist
// router.delete('/:id/remove', auth, playlistController.removeSongFromPlaylist); // Remove song from playlist

module.exports = router;
