// routes/ratingRoutes.js

const express = require('express');
const router = express.Router();

const { rateSong, getSongRating } = require('../controllers/ratingController');
const authMiddleware = require('../middleware/auth');

// Apply authMiddleware to secure the routes
router.post('/rate', authMiddleware, rateSong);  // Post request to rate a song
router.get('/rating/:songId', getSongRating);   // Get request to fetch rating for a song

module.exports = router;
