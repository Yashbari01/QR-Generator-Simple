// routes/commentRoutes.js

const express = require('express');
const router = express.Router();
const commentController = require('../controllers/commentController');
const auth = require('../middleware/auth');

// Comment Routes
router.post('/:songId', auth, commentController.addComment); // Add comment to a song
router.get('/:commentId', auth, commentController.getComments); // Delete a comment

module.exports = router;
