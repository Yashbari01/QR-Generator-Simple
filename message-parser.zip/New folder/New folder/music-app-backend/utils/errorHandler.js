// utils/errorHandler.js

const handleError = (err, res) => {
    const errorDetails = {
      message: err.message || 'Internal Server Error',
      status: err.status || 500,
      stack: err.stack || '',
    };
    res.status(errorDetails.status).json(errorDetails);
  };
  
  module.exports = handleError;
  