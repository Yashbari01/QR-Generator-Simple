// // utils/logger.js

// const fs = require('fs');
// const path = require('path');

// const logFilePath = path.join(__dirname, '../logs/app.log');
// console.log('logFilePath: ', logFilePath);

// exports.logToFile = (message) => {
//   const timestamp = new Date().toISOString();
//   fs.appendFileSync(logFilePath, `[${timestamp}] ${message}\n`);
// };

// exports.logToConsole = (message) => {
//   console.log(message);
// };


const fs = require('fs');
const path = require('path');

const logFilePath = path.join(__dirname, '../logs/app.log');

// Function to log to a file
const logToFile = (message) => {
  const timestamp = new Date().toISOString();
  fs.appendFileSync(logFilePath, `[${timestamp}] ${message}\n`);
};

// Function to log to the console
const logToConsole = (message) => {
  console.log(message);
};

// The error method will log both to the console and to the file
const logError = (message) => {
  const errorMessage = `[ERROR] ${message}`;
  logToFile(errorMessage); // Log to file
  logToConsole(errorMessage); // Log to console
};

// Export the logger methods
module.exports = {
  logToFile,
  logToConsole,
  logError, // Now you can use logger.logError in your server.js
};
