// controllers/ratingController.js

const Rating = require('../models/Rating');
const { logToConsole } = require('../utils/logger');
const handleError = require('../utils/errorHandler');
const authMiddleware = require('../middleware/auth');

// Rate a Song
exports.rateSong = async (req, res) => {
  const { songId, rating } = req.body;

  try {
    const existingRating = await Rating.findOne({ user: req.userId, song: songId });
    if (existingRating) {
      existingRating.rating = rating;
      await existingRating.save();
    } else {
      const newRating = new Rating({
        user: req.userId,
        song: songId,
        rating,
      });

      await newRating.save();
    }

    res.status(201).json({ message: 'Rating submitted successfully' });
  } catch (error) {
    handleError(error, res);
  }
};

// Get Rating for a Song
exports.getSongRating = async (req, res) => {
  const { songId } = req.params;
  
  try {
    const rating = await Rating.findOne({ song: songId }).populate('user');
    if (!rating) return res.status(404).json({ message: 'No ratings found for this song' });
    res.json(rating);
  } catch (error) {
    handleError(error, res);
  }
};
