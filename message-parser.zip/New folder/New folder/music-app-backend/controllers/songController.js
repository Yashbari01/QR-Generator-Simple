const Song = require('../models/Song');
const { getRecommendedSongs } = require('../services/recommendations');
const { searchSongs } = require('../services/search');
const handleError = require('../utils/errorHandler');
const authMiddleware = require('../middleware/auth');
const rateLimit = require('../middleware/rateLimit');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Ensure that the 'uploads' directory exists before saving any files
const uploadsDir = path.join(__dirname, '../uploads'); // Relative path to uploads directory

// Check if the directory exists, if not, create it
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true }); // Create uploads directory if it doesn't exist
  console.log('Uploads directory created');
}

// Set up Multer storage engine for saving files
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir); // Files will be saved to 'uploads' folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Use timestamp to avoid file name conflicts
  }
});

// Initialize multer with the defined storage configuration
const upload = multer({ storage: storage }).single('file'); // We assume 'file' is the name of the form field

// Create a New Song (Admin)
exports.createSong = async (req, res) => {
  const { title, artist, album, genre, duration } = req.body;
  console.log('title, artist, album, genre, duration: ', title, artist, album, genre, duration);

  // Handle file upload
  upload(req, res, async (err) => {
    if (err) {
      return res.status(500).json({ message: 'File upload failed', error: err.message });
    }

    console.log('file: ', file);
    // Ensure that file is uploaded
    if (!req.file) {
      return res.status(400).json({ message: 'File is required' });
    }

    try {
      // Create the new song record in the database
      const newSong = new Song({
        title,
        artist,
        album,
        genre,
        file:`${req.file.filename}`,
        fileUrl: `/uploads/${req.file.filename}`, // Store the file URL
        duration: parseInt(duration), // Ensure duration is a number
      });

      // Save the new song to the database
      await newSong.save();
      res.status(201).json({ message: 'Song created successfully', song: newSong });
    } catch (error) {
      handleError(error, res);
    }
  });
};

// Get All Songs
exports.getAllSongs = async (req, res) => {
  try {
    const songs = await Song.find();
    res.json(songs);
  } catch (error) {
    handleError(error, res);
  }
};

// Search Songs
exports.searchForSongs = async (req, res) => {
  const { query } = req.query;
  
  try {
    const songs = await searchSongs(query);
    res.json(songs);
  } catch (error) {
    handleError(error, res);
  }
};

// Get Song Recommendations
exports.getSongRecommendations = async (req, res) => {
  const userId = req.userId;
  
  try {
    const recommendations = await getRecommendedSongs(userId);
    res.json(recommendations);
  } catch (error) {
    handleError(error, res);
  }
};



// // controllers/songController.js

// const Song = require('../models/Song');
// const { getRecommendedSongs } = require('../services/recommendations');
// const { searchSongs } = require('../services/search');
// const { logToConsole } = require('../utils/logger');
// const handleError = require('../utils/errorHandler');
// const authMiddleware = require('../middleware/auth');
// const rateLimit = require('../middleware/rateLimit');

// // Create a New Song (Admin)
// exports.createSong = async (req, res) => {
//   const { title, artist, album, genre, fileUrl, duration } = req.body;
  
//   try {
//     const newSong = new Song({
//       title,
//       artist,
//       album,
//       genre,
//       fileUrl,
//       duration,
//     });

//     await newSong.save();
//     res.status(201).json({ message: 'Song created successfully', song: newSong });
//   } catch (error) {
//     handleError(error, res);
//   }
// };

// // Get All Songs
// exports.getAllSongs = async (req, res) => {
//   try {
//     const songs = await Song.find();
//     res.json(songs);
//   } catch (error) {
//     handleError(error, res);
//   }
// };

// // Search Songs
// exports.searchForSongs = async (req, res) => {
//   const { query } = req.query;
  
//   try {
//     const songs = await searchSongs(query);
//     res.json(songs);
//   } catch (error) {
//     handleError(error, res);
//   }
// };

// // Get Song Recommendations
// exports.getSongRecommendations = async (req, res) => {
//   const userId = req.userId;
  
//   try {
//     const recommendations = await getRecommendedSongs(userId);
//     res.json(recommendations);
//   } catch (error) {
//     handleError(error, res);
//   }
// };
