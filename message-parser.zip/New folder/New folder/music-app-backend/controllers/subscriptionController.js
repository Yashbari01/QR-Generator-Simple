// controllers/subscriptionController.js

const Subscription = require('../models/Subscription');
const User = require('../models/User');

// Get User Subscription
exports.getUserSubscription = async (req, res) => {
  const userId = req.userId;  // Extracted from JWT middleware
  try {
    const subscription = await Subscription.findOne({ user: userId });
    if (!subscription) return res.status(404).json({ message: 'No subscription found' });

    res.status(200).json(subscription);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// Update Subscription Plan
exports.updateSubscription = async (req, res) => {
  const { plan } = req.body;
  const userId = req.userId;  // Extracted from JWT middleware
  try {
    const subscription = await Subscription.findOneAndUpdate(
      { user: userId },
      { plan },
      { new: true }
    );
    if (!subscription) return res.status(404).json({ message: 'Subscription not found' });

    res.status(200).json(subscription);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
