// controllers/notificationController.js

const Notification = require('../models/Notification');
const User = require('../models/User');

// Get User Notifications
exports.getUserNotifications = async (req, res) => {
  const userId = req.userId;  // Extracted from JWT middleware
  try {
    const notifications = await Notification.find({ user: userId });
    res.status(200).json(notifications);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// Mark Notification as Read
exports.markNotificationRead = async (req, res) => {
  const { notificationId } = req.params;
  try {
    const notification = await Notification.findByIdAndUpdate(notificationId, { read: true }, { new: true });
    if (!notification) return res.status(404).json({ message: 'Notification not found' });

    res.status(200).json(notification);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
