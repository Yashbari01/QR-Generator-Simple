// controllers/playlistController.js

const Playlist = require('../models/Playlist');
const Song = require('../models/Song');

// Create Playlist
exports.createPlaylist = async (req, res) => {
  const { name, description, songIds } = req.body;
  const userId = req.userId;  // Extracted from JWT middleware
  try {
    const playlist = new Playlist({ name, description, user: userId, songs: songIds });
    await playlist.save();

    // Add playlist to user's profile
    await User.findByIdAndUpdate(userId, { $push: { playlists: playlist._id } });

    res.status(201).json(playlist);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// Get User Playlists
exports.getUserPlaylists = async (req, res) => {
  const userId = req.userId;  // Extracted from JWT middleware
  try {
    const playlists = await Playlist.find({ user: userId }).populate('songs');
    res.status(200).json(playlists);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
