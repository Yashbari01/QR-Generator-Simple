// controllers/commentController.js

const Comment = require('../models/Comment');
const { logToConsole } = require('../utils/logger');
const handleError = require('../utils/errorHandler');
const authMiddleware = require('../middleware/auth');

// Add Comment to Song
exports.addComment = async (req, res) => {
  const { songId, commentText } = req.body;
  
  try {
    const newComment = new Comment({
      user: req.userId,
      song: songId,
      commentText,
    });

    await newComment.save();
    res.status(201).json({ message: 'Comment added successfully', comment: newComment });
  } catch (error) {
    handleError(error, res);
  }
};

// Get Comments for a Song
exports.getComments = async (req, res) => {
  const { songId } = req.params;
  
  try {
    const comments = await Comment.find({ song: songId }).populate('user');
    res.json(comments);
  } catch (error) {
    handleError(error, res);
  }
};
