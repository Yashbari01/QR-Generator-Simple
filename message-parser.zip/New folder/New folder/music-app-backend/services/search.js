// services/search.js

const Song = require('../models/Song');

exports.searchSongs = async (query) => {
  // Searching by title, artist, genre, etc.
  const searchResult = await Song.find({
    $or: [
      { title: { $regex: query, $options: 'i' } },
      { artist: { $regex: query, $options: 'i' } },
      { genre: { $regex: query, $options: 'i' } },
    ],
  });

  return searchResult;
};
