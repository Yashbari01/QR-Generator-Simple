// services/recommendations.js

const Song = require('../models/Song');

exports.getRecommendedSongs = async (userId) => {
  // For simplicity, just returning the most played songs
  const recommendedSongs = await Song.find()
    .sort({ playCount: -1 })
    .limit(10);

  return recommendedSongs;
};
