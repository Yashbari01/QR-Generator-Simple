// models/Tag.js

const mongoose = require('mongoose');

const tagSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },  // e.g., 'Relaxing', 'Upbeat'
  description: { type: String },  // A brief description
});

module.exports = mongoose.model('Tag', tagSchema);
