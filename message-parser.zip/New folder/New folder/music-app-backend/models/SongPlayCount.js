// models/SongPlayCount.js

const mongoose = require('mongoose');

const songPlayCountSchema = new mongoose.Schema({
  song: { type: mongoose.Schema.Types.ObjectId, ref: 'Song', required: true },  // Song being played
  playCount: { type: Number, default: 0 },  // Number of times the song has been played
  lastPlayed: { type: Date },  // When the song was last played
});

module.exports = mongoose.model('SongPlayCount', songPlayCountSchema);
