// models/ActivityLog.js

const mongoose = require('mongoose');

const activityLogSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },  // User performing the action
  action: { type: String, required: true },  // Action performed (e.g., "played song", "liked song")
  song: { type: mongoose.Schema.Types.ObjectId, ref: 'Song' },  // Song associated with the action
  timestamp: { type: Date, default: Date.now },  // When the action occurred
});

module.exports = mongoose.model('ActivityLog', activityLogSchema);
