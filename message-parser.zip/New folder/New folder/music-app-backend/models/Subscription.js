// models/Subscription.js

const mongoose = require('mongoose');

const subscriptionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  plan: { type: String, enum: ['Free', 'Premium', 'VIP'], required: true },  // Subscription plan
  startDate: { type: Date, default: Date.now },
  renewalDate: { type: Date, required: true },
  status: { type: String, enum: ['Active', 'Inactive'], default: 'Active' },
});

module.exports = mongoose.model('Subscription', subscriptionSchema);
