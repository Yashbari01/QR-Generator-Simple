// models/Notification.js

const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },  // User receiving the notification
  type: { type: String, enum: ['New Song', 'Comment', 'Like', 'Promo'], required: true },  // Type of notification
  message: { type: String, required: true },  // The notification message
  read: { type: Boolean, default: false },  // Whether the notification has been read
  timestamp: { type: Date, default: Date.now },  // When the notification was created
});

module.exports = mongoose.model('Notification', notificationSchema);
