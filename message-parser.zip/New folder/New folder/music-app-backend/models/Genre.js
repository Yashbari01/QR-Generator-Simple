// models/Genre.js

const mongoose = require('mongoose');

const genreSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },  // e.g., Pop, Rock, Hip-Hop
  description: { type: String },  // Description of the genre
});

module.exports = mongoose.model('Genre', genreSchema);
