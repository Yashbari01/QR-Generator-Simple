// server.js

const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./db/db'); // Importing DB connection
const morgan = require('morgan');
const cors = require('cors');
const path = require('path');

// Import Routes
const userRoutes = require('./routes/userRoutes');
const songRoutes = require('./routes/songRoutes');
const commentRoutes = require('./routes/commentRoutes');
const playlistRoutes = require('./routes/playlistRoutes');
const subscriptionRoutes = require('./routes/subscriptionRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const ratingRoutes = require('./routes/ratingRoutes');

// Import Middleware
const auth = require('./middleware/auth');
const rateLimit = require('./middleware/rateLimit');
const errorHandler = require('./middleware/errorHandler');

// Import Services
const recommendationsService = require('./services/recommendations');
const searchService = require('./services/search');

// Import Utils
const logger = require('./utils/logger');

// Load environment variables
dotenv.config();

// Initialize the app
const app = express();

// Middleware to log requests
app.use(morgan('dev'));

// Middleware to handle CORS (Cross-Origin Resource Sharing)
app.use(cors());

// Middleware to parse incoming JSON requests
app.use(express.json());

// Set view engine (EJS)
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views')); // Optional: specify where your views are located

// Database Connection
connectDB();

// Routes
app.use('/api/users', userRoutes); // User Routes (login, register, profile)
app.use('/api/songs', songRoutes); // Song Routes (create, play, fetch)
app.use('/api/comments', commentRoutes); // Comment Routes (add, delete comments)
app.use('/api/playlists', playlistRoutes); // Playlist Routes (create, update, delete)
app.use('/api/subscriptions', subscriptionRoutes); // Subscription Routes (upgrade, view)
app.use('/api/notifications', notificationRoutes); // Notification Routes (send, view)
app.use('/api/ratings', ratingRoutes); // Rating Routes (rate songs)

// Services Routes (optional if you want to expose them as endpoints)
app.get('/api/recommendations', auth, recommendationsService.getRecommendedSongs); // Song Recommendations Service
app.get('/api/search', searchService.searchSongs); // Song Search Service

// Render the API Documentation page
app.get('/api-docs', (req, res) => {
  const apiRoutes = [
    {
      name: 'User Routes',
      routes: [
        { 
          method: 'POST', 
          path: '/api/users/login', 
          description: 'Login a user', 
          payload: {
            username: 'string (required)',
            password: 'string (required)',
          },
          examplePayload: {
            username: 'john_doe',
            password: '12345',
          }
        },
        { 
          method: 'POST', 
          path: '/api/users/register', 
          description: 'Register a new user', 
          payload: {
            username: 'string (required)',
            email: 'string (required, valid email)',
            password: 'string (required, min 6 characters)',
          },
          examplePayload: {
            username: 'john_doe',
            email: 'john_doe@example.com',
            password: '12345',
          }
        },
        { 
          method: 'GET', 
          path: '/api/users/:id', 
          description: 'Get user profile (By user ID)',
        },
        { 
          method: 'PUT', 
          path: '/api/users/:id', 
          description: 'Update user profile', 
          payload: {
            username: 'string (optional)',
            email: 'string (optional)',
          },
          examplePayload: {
            username: 'john_doe_updated',
            email: 'john_doe_updated@example.com',
          }
        },
      ],
    },
    {
      name: 'Song Routes',
      routes: [
        { 
          method: 'GET', 
          path: '/api/songs', 
          description: 'Fetch all songs',
        },
        { 
          method: 'POST', 
          path: '/api/songs', 
          description: 'Create a new song', 
          payload: {
            title: 'string (required)',
            artist: 'string (required)',
            album: 'string (optional)',
            genre: 'string (required)',
            fileUrl: 'string (required)',
          },
          examplePayload: {
            title: 'Song Title',
            artist: 'Artist Name',
            album: 'Album Name',
            genre: 'Rock',
            fileUrl: 'https://example.com/song.mp3',
          }
        },
        { 
          method: 'GET', 
          path: '/api/songs/:id', 
          description: 'Get a specific song by ID',
        },
        { 
          method: 'GET', 
          path: '/api/songs/genre/:genre', 
          description: 'Fetch songs by genre',
        },
      ],
    },
    {
      name: 'Comment Routes',
      routes: [
        { 
          method: 'POST', 
          path: '/api/comments', 
          description: 'Add a comment to a song', 
          payload: {
            songId: 'string (required)',
            userId: 'string (required)',
            commentText: 'string (required)',
          },
          examplePayload: {
            songId: '12345',
            userId: '67890',
            commentText: 'Great song!',
          }
        },
        { 
          method: 'DELETE', 
          path: '/api/comments/:id', 
          description: 'Delete a comment by ID',
        },
      ],
    },
    {
      name: 'Playlist Routes',
      routes: [
        { 
          method: 'POST', 
          path: '/api/playlists', 
          description: 'Create a new playlist', 
          payload: {
            userId: 'string (required)',
            title: 'string (required)',
            description: 'string (optional)',
          },
          examplePayload: {
            userId: '12345',
            title: 'My Playlist',
            description: 'A collection of my favorite songs.',
          }
        },
        { 
          method: 'GET', 
          path: '/api/playlists/:id', 
          description: 'Get a specific playlist by ID',
        },
        { 
          method: 'PUT', 
          path: '/api/playlists/:id', 
          description: 'Update playlist details', 
          payload: {
            title: 'string (optional)',
            description: 'string (optional)',
          },
          examplePayload: {
            title: 'Updated Playlist Title',
            description: 'Updated description of playlist.',
          }
        },
        { 
          method: 'DELETE', 
          path: '/api/playlists/:id', 
          description: 'Delete a playlist',
        },
      ],
    },
    {
      name: 'Subscription Routes',
      routes: [
        { 
          method: 'POST', 
          path: '/api/subscriptions', 
          description: 'Create or upgrade a subscription', 
          payload: {
            userId: 'string (required)',
            plan: 'string (required, e.g., "premium", "basic")',
          },
          examplePayload: {
            userId: '12345',
            plan: 'premium',
          }
        },
        { 
          method: 'GET', 
          path: '/api/subscriptions/:userId', 
          description: 'Get subscription details for a user',
        },
      ],
    },
    {
      name: 'Notification Routes',
      routes: [
        { 
          method: 'POST', 
          path: '/api/notifications', 
          description: 'Send a notification', 
          payload: {
            userId: 'string (required)',
            message: 'string (required)',
          },
          examplePayload: {
            userId: '12345',
            message: 'You have a new message!',
          }
        },
        { 
          method: 'GET', 
          path: '/api/notifications/:userId', 
          description: 'Get notifications for a user',
        },
      ],
    },
    {
      name: 'Rating Routes',
      routes: [
        { 
          method: 'POST', 
          path: '/api/ratings', 
          description: 'Rate a song', 
          payload: {
            userId: 'string (required)',
            songId: 'string (required)',
            rating: 'number (required, 1 to 5)',
          },
          examplePayload: {
            userId: '12345',
            songId: '67890',
            rating: 5,
          }
        },
        { 
          method: 'GET', 
          path: '/api/ratings/:songId', 
          description: 'Get ratings for a song',
        },
      ],
    },
  ];

  res.render('apiDocs', { apiRoutes });
});

// Middleware for Rate-Limiting
app.use(rateLimit);

// Global error handler middleware
app.use(errorHandler);

// Catch-all 404 handler
app.use((req, res, next) => {
  const error = new Error('Not Found');
  error.status = 404;
  next(error);
});

// Global error handler for uncaught errors
app.use((err, req, res, next) => {
  logger.logError(err.stack); // Use logError method instead
  res.status(err.status || 500).json({ message: err.message || 'Internal Server Error' });
});

// Port and Server Start
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
