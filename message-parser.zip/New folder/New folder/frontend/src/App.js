import React, { useState, useEffect } from 'react';
import { FaUser, FaEnvelope, FaSadTear, FaCheckCircle } from 'react-icons/fa';  // Importing icons

const cryingEmoji = "/giphy.webp";  // Make sure this path is correct

const App = () => {
  const [inactive, setInactive] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);

  let inactivityTimer = null;

  const resetInactivityTimer = () => {
    setInactive(false);
    if (inactivityTimer) {
      clearTimeout(inactivityTimer);
    }
    inactivityTimer = setTimeout(() => {
      setInactive(true); // Trigger inactivity
      setShowPrompt(true); // Show prompt after 10 seconds
    }, 10000); // 10 seconds of inactivity
  };

  useEffect(() => {
    window.addEventListener('mousemove', resetInactivityTimer);
    window.addEventListener('keydown', resetInactivityTimer);

    resetInactivityTimer();

    return () => {
      window.removeEventListener('mousemove', resetInactivityTimer);
      window.removeEventListener('keydown', resetInactivityTimer);
      clearTimeout(inactivityTimer);
    };
  }, []);

  return (
    <div
      className="h-screen flex justify-center items-center bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600"
      style={{
        cursor: inactive ? 'none' : 'default', // Hide cursor when inactive
      }}
    >
      <div className="w-full max-w-lg bg-white p-8 rounded-lg shadow-lg relative">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-6">User Interaction Form</h1>

        <form className="space-y-6">
          {/* Name Input */}
          <div className="flex items-center space-x-3">
            <FaUser className="text-gray-500" />
            <input
              type="text"
              id="name"
              name="name"
              required
              placeholder="Enter your name"
              className="w-full p-3 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Email Input */}
          <div className="flex items-center space-x-3">
            <FaEnvelope className="text-gray-500" />
            <input
              type="email"
              id="email"
              name="email"
              required
              placeholder="Enter your email"
              className="w-full p-3 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-40 bg-indigo-500 text-white py-3 rounded-md shadow-lg hover:bg-indigo-600 transition duration-200"
          >
            <FaCheckCircle className="inline mr-2" />
            Submit
          </button>
        </form>

        {/* Inactivity Behavior */}
        {inactive && (
          <div className="absolute inset-0 flex justify-center items-center bg-opacity-50 bg-black rounded-lg">
            <img src={cryingEmoji} alt="crying emoji" className="h-32 w-32" />
          </div>
        )}

        {/* Inactivity Prompt */}
        {/* {showPrompt && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-red-500 text-white py-3 px-6 rounded-md shadow-lg text-sm">
            <p>
              <FaSadTear className="inline mr-2" /> 
              Looks like you haven't moved your mouse for a while! Are you still there?
            </p>
          </div>
        )} */}
      </div>
    </div>
  );
};

export default App;
