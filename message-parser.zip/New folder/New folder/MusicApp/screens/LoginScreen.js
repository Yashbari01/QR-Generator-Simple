import React, { useState } from 'react';
import { View, TextInput, Button, Alert, StyleSheet } from 'react-native';
import axios from 'axios';
import { IconButton } from 'react-native-paper';

const LoginScreen = ({ navigation }) => {
  const [email, setemail] = useState('');
  const [password, setPassword] = useState('');

  // const handleLogin = async () => {
  //   try {
  //     const response = await axios.post('http://192.168.1.13:5000/api/users/login', { email, password });
  //     if (response.status === 200) {
  //       // Assuming the response has a user ID or token
  //       navigation.replace('Home');
  //     }
  //   } catch (error) {
  //     Alert.alert('Error', 'Invalid login credentials');
  //   }
  // };

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://192.168.1.13:5000/api/users/login', { email, password });
      if (response.status === 200) {
        // Assuming the response contains a token
        const token = response.data.token; // Adjust based on the response structure
  
        // Store the token locally, using AsyncStorage (or another secure method)
        await AsyncStorage.setItem('authToken', token);
  
        // Navigate to HomeScreen
        navigation.replace('Home');
      }
    } catch (error) {
      Alert.alert('Error', 'Invalid login credentials');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setemail}
        style={styles.input}
      />
      <TextInput
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
        style={styles.input}
      />
      <Button title="Login" onPress={handleLogin} />
      <Button title="Register" onPress={() => navigation.navigate('Register')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  input: {
    borderBottomWidth: 1,
    marginBottom: 20,
    padding: 10,
  },
});

export default LoginScreen;
