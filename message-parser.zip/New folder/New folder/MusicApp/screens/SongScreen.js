// screens/SongScreen.js
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
import axios from 'axios';

const SongScreen = ({ route }) => {
  const { songId } = route.params;  // Ensure `route.params` is used here
  const [song, setSong] = useState(null);

  useEffect(() => {
    const fetchSong = async () => {
      try {
        const response = await axios.get(`http://192.168.1.13:5000/api/songs/${songId}`);
        setSong(response.data);
      } catch (error) {
        console.error('Error fetching song:', error);
      }
    };
    fetchSong();
  }, [songId]);

  if (!song) {
    return <Text>Loading...</Text>;
  }

  return (
    <View style={styles.container}>
      <Text>{song.title}</Text>
      <Text>{song.artist}</Text>
      <Text>{song.album}</Text>
      <Text>{song.genre}</Text>
      <Button title="Add to Playlist" onPress={() => {/* handle add to playlist */}} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
});

export default SongScreen;
