// screens/HomeScreen.js
import React, { useEffect, useState } from 'react';
import { View, FlatList, Text, StyleSheet, Button } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage'; // Import AsyncStorage
import PlaylistList from '../components/PlaylistList';

const HomeScreen = ({ navigation }) => {
  const [songs, setSongs] = useState([]);
  const [playlists, setPlaylists] = useState([]);

  // Fetch songs from API
  useEffect(() => {
    const fetchSongs = async () => {
      try {
        const token = await AsyncStorage.getItem('authToken'); // Get the token from AsyncStorage

        if (token) {
          const response = await axios.get('http://192.168.1.13:5000/api/songs', {
            headers: {
              Authorization: `Bearer ${token}`, // Pass the token in the Authorization header
            },
          });
          setSongs(response.data);
        } else {
          Alert.alert('Error', 'User not authenticated');
        }
      } catch (error) {
        console.error('Error fetching songs:', error);
      }
    };

    fetchSongs();
  }, []);

  // Fetch playlists from API
  useEffect(() => {
    const fetchPlaylists = async () => {
      try {
        const token = await AsyncStorage.getItem('authToken'); // Get the token from AsyncStorage

        if (token) {
          const response = await axios.get('http://192.168.1.13:5000/api/playlists', {
            headers: {
              Authorization: `Bearer ${token}`, // Pass the token in the Authorization header
            },
          });
          setPlaylists(response.data);
        } else {
          Alert.alert('Error', 'User not authenticated');
        }
      } catch (error) {
        console.error('Error fetching playlists:', error);
      }
    };

    fetchPlaylists();
  }, []);

  // Handle selecting a playlist
  const onSelectPlaylist = (playlistId) => {
    navigation.navigate('Playlist', { playlistId });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Songs</Text>
      {songs.length === 0 ? (
        <Text>No songs available</Text> // Display message if no songs
      ) : (
        <FlatList
          data={songs}
          keyExtractor={(item) => item._id.toString()}
          renderItem={({ item }) => (
            <View style={styles.songItem}>
              <Text>{item.title}</Text>
              <Button title="View Song" onPress={() => navigation.navigate('Song', { songId: item._id })} />
            </View>
          )}
        />
      )}

      <Text style={styles.header}>Playlists</Text>
      {playlists.length === 0 ? (
        <Text>No playlists available</Text> // Display message if no playlists
      ) : (
        <PlaylistList playlists={playlists} onSelectPlaylist={onSelectPlaylist} />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  songItem: {
    padding: 10,
    borderBottomWidth: 1,
    marginBottom: 10,
  },
});

export default HomeScreen;
