// screens/PlaylistScreen.js
import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, Button } from 'react-native';
import axios from 'axios';

const PlaylistScreen = ({ route, navigation }) => {
  const { playlistId } = route?.params || {}; // Safe access to route.params
  const [playlist, setPlaylist] = useState(null);

  useEffect(() => {
    const fetchPlaylist = async () => {
      try {
        const response = await axios.get(`http://192.168.1.13:5000/api/playlists/${playlistId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setPlaylist(response.data);
      } catch (error) {
        console.error('Error fetching playlist:', error);
      }
    };

    if (playlistId) {
      fetchPlaylist();
    }
  }, [playlistId]);

  if (!playlistId) {
    return (
      <View style={styles.container}>
        <Text>No data available</Text> {/* Handle case when playlistId is missing */}
      </View>
    );
  }

  if (!playlist) {
    return <Text>Loading...</Text>;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.playlistTitle}>{playlist.title}</Text>
      {playlist.description && <Text style={styles.playlistDescription}>{playlist.description}</Text>}
      <FlatList
        data={playlist.songs}
        keyExtractor={(item) => item._id.toString()}
        renderItem={({ item }) => (
          <View style={styles.songItem}>
            <Text>{item.title}</Text>
            <Button title="Play" onPress={() => {}} />
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  playlistTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  playlistDescription: {
    fontSize: 16,
    marginVertical: 10,
  },
  songItem: {
    padding: 10,
    borderBottomWidth: 1,
    marginBottom: 10,
  },
});

export default PlaylistScreen;
