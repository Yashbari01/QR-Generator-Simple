// App.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider as PaperProvider } from 'react-native-paper';
import LoginScreen from './screens/LoginScreen';
import RegisterScreen from './screens/RegisterScreen';
import HomeScreen from './screens/HomeScreen';
import PlaylistScreen from './screens/PlaylistScreen';
import SongScreen from './screens/SongScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <PaperProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Login">
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="Register" component={RegisterScreen} />
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Playlist" component={PlaylistScreen} />
          <Stack.Screen name="Song" component={SongScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </PaperProvider>
  );
}



// import React from 'react';
// import { NavigationContainer } from '@react-navigation/native';
// import { createStackNavigator } from '@react-navigation/stack';
// import { Provider as PaperProvider } from 'react-native-paper';
// import LoginScreen from './screens/LoginScreen';
// import RegisterScreen from './screens/RegisterScreen';
// import HomeScreen from './screens/HomeScreen';
// import PlaylistScreen from './screens/PlaylistScreen';
// import SongScreen from './screens/SongScreen';
// import UserProfileScreen from './screens/UserProfileScreen'; // Import UserProfileScreen

// const Stack = createStackNavigator();

// export default function App() {
//   return (
//     <PaperProvider>
//       <NavigationContainer>
//         <Stack.Navigator initialRouteName="Login">
//           {/* Make sure you define each screen using the Screen component */}
//           <Stack.Screen name="Login" component={LoginScreen} />
//           <Stack.Screen name="Register" component={RegisterScreen} />
//           <Stack.Screen name="Home" component={HomeScreen} 
//             options={({ navigation }) => ({
//               headerRight: () => (
//                 <Button
//                   onPress={() => navigation.navigate('UserProfile')}  // Navigate to UserProfile
//                   title="Profile"
//                 />
//               ),
//             })}
//           />
//           <Stack.Screen name="Playlist" component={PlaylistScreen} />
//           <Stack.Screen name="Song" component={SongScreen} />
//           <Stack.Screen name="UserProfile" component={UserProfileScreen} /> {/* UserProfile Screen */}
//         </Stack.Navigator>
//       </NavigationContainer>
//     </PaperProvider>
//   );
// }
