// components/SongList.js
import React from 'react';
import { FlatList, View, Text, Button } from 'react-native';

const SongList = ({ songs, onSelectSong }) => {
  return (
    <FlatList
      data={songs}
      keyExtractor={(item) => item._id}
      renderItem={({ item }) => (
        <View>
          <Text>{item.title}</Text>
          <Button title="View" onPress={() => onSelectSong(item._id)} />
        </View>
      )}
    />
  );
};

export default SongList;
