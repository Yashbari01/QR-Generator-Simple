// // import { Image, StyleSheet, Platform } from 'react-native';

// // import { HelloWave } from '@/components/HelloWave';
// // import ParallaxScrollView from '@/components/ParallaxScrollView';
// // import { ThemedText } from '@/components/ThemedText';
// // import { ThemedView } from '@/components/ThemedView';

// // export default function HomeScreen() {
// //   return (
// //     <ParallaxScrollView
// //       headerBackgroundColor={{ light: '#A1CEDC', dark: '#1D3D47' }}
// //       headerImage={
// //         <Image
// //           source={require('@/assets/images/partial-react-logo.png')}
// //           style={styles.reactLogo}
// //         />
// //       }>
// //       <ThemedView style={styles.titleContainer}>
// //         <ThemedText type="title">Welcome!</ThemedText>
// //         <HelloWave />
// //       </ThemedView>
// //       <ThemedView style={styles.stepContainer}>
// //         <ThemedText type="subtitle">Step 1: Try it</ThemedText>
// //         <ThemedText>
// //           Edit <ThemedText type="defaultSemiBold">app/(tabs)/index.tsx</ThemedText> to see changes.
// //           Press{' '}
// //           <ThemedText type="defaultSemiBold">
// //             {Platform.select({ ios: 'cmd + d', android: 'cmd + m' })}
// //           </ThemedText>{' '}
// //           to open developer tools.
// //         </ThemedText>
// //       </ThemedView>
// //       <ThemedView style={styles.stepContainer}>
// //         <ThemedText type="subtitle">Step 2: Explore</ThemedText>
// //         <ThemedText>
// //           Tap the Explore tab to learn more about what's included in this starter app.
// //         </ThemedText>
// //       </ThemedView>
// //       <ThemedView style={styles.stepContainer}>
// //         <ThemedText type="subtitle">Step 3: Get a fresh start</ThemedText>
// //         <ThemedText>
// //           When you're ready, run{' '}
// //           <ThemedText type="defaultSemiBold">npm run reset-project</ThemedText> to get a fresh{' '}
// //           <ThemedText type="defaultSemiBold">app</ThemedText> directory. This will move the current{' '}
// //           <ThemedText type="defaultSemiBold">app</ThemedText> to{' '}
// //           <ThemedText type="defaultSemiBold">app-example</ThemedText>.
// //         </ThemedText>
// //       </ThemedView>
// //     </ParallaxScrollView>
// //   );
// // }

// // const styles = StyleSheet.create({
// //   titleContainer: {
// //     flexDirection: 'row',
// //     alignItems: 'center',
// //     gap: 8,
// //   },
// //   stepContainer: {
// //     gap: 8,
// //     marginBottom: 8,
// //   },
// //   reactLogo: {
// //     height: 178,
// //     width: 290,
// //     bottom: 0,
// //     left: 0,
// //     position: 'absolute',
// //   },
// // });


// // app/(tabs)/index.tsx
// import React from 'react';
// import { Text, View, Button, StyleSheet, TouchableOpacity } from 'react-native';
// import { useAuth } from '../context/AuthContext';
// import { useRouter } from 'expo-router';
// import { MaterialCommunityIcons } from '@expo/vector-icons';

// const HomeScreen = () => {
//   const { user, logoutUser } = useAuth();
//   const router = useRouter();

//   return (
//     <View style={styles.container}>
//       <View style={styles.content}>
//         {user ? (
//           <>
//             <Text style={styles.welcomeText}>Welcome, {user.username}</Text>
//             <View style={styles.card}>
//               <TouchableOpacity style={styles.button} onPress={() => router.push('/profile')}>
//                 <MaterialCommunityIcons name="account" size={24} color="#fff" />
//                 <Text style={styles.buttonText}>Go to Profile</Text>
//               </TouchableOpacity>
//               <TouchableOpacity style={styles.logoutButton} onPress={logoutUser}>
//                 <MaterialCommunityIcons name="logout" size={24} color="#fff" />
//                 <Text style={styles.buttonText}>Logout</Text>
//               </TouchableOpacity>
//             </View>
//           </>
//         ) : (
//           <>
//             <Text style={styles.welcomeText}>Welcome, Guest</Text>
//             <View style={styles.card}>
//               <TouchableOpacity style={styles.button} onPress={() => router.push('/login')}>
//                 <MaterialCommunityIcons name="login" size={24} color="#fff" />
//                 <Text style={styles.buttonText}>Login</Text>
//               </TouchableOpacity>
//               <TouchableOpacity style={styles.button} onPress={() => router.push('/register')}>
//                 <MaterialCommunityIcons name="account-plus" size={24} color="#fff" />
//                 <Text style={styles.buttonText}>Register</Text>
//               </TouchableOpacity>
//             </View>
//           </>
//         )}
//       </View>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#f4f6f8', // Light background for contrast
//     justifyContent: 'center',
//     alignItems: 'center',
//     padding: 16,
//   },
//   content: {
//     width: '100%',
//     maxWidth: 350,
//     alignItems: 'center',
//   },
//   welcomeText: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     color: '#333',
//     marginBottom: 20,
//     textAlign: 'center',
//   },
//   card: {
//     width: '100%',
//     backgroundColor: '#fff',
//     padding: 20,
//     borderRadius: 10,
//     shadowColor: '#000',
//     shadowOffset: { width: 0, height: 4 },
//     shadowOpacity: 0.1,
//     shadowRadius: 5,
//     elevation: 5,
//     marginBottom: 20,
//   },
//   button: {
//     flexDirection: 'row',
//     backgroundColor: '#6200ee', // Purple button color
//     padding: 12,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginBottom: 12,
//     justifyContent: 'center',
//   },
//   logoutButton: {
//     flexDirection: 'row',
//     backgroundColor: '#f44336', // Red button for logout
//     padding: 12,
//     borderRadius: 8,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   buttonText: {
//     color: '#fff',
//     fontSize: 16,
//     marginLeft: 8,
//     fontWeight: '600',
//   },
// });

// export default HomeScreen;


import { Stack } from 'expo-router';
import React from 'react';
import { View, Text, Button, StyleSheet, useWindowDimensions } from 'react-native';
import { useRouter } from 'expo-router';

const Index = () => {
  const router = useRouter();  // Using the router hook from expo-router
  const { width } = useWindowDimensions();  // Access screen width for responsiveness

  React.useEffect(() => {
    // Automatically navigate to the "home" screen by default
    router.push('/home');  // This ensures the "home" tab is shown by default
  }, [router]);

  return null; // Since we are redirecting to the home screen, no content is shown here
};

export default Index;
