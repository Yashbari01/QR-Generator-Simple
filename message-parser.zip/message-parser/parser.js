const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3030; // You can use any available port

app.use(bodyParser.raw({ type: 'application/octet-stream' }));

const MESSAGE_TYPES = {
    0x0001: 'Terminal General Response',
    0x0100: 'Terminal Register',
    0x8100: 'Terminal Register Response',
    0x0102: 'Terminal Authentication',
    0x8001: 'Platform General Response',
    0x0200: 'Location Information Report',
    0x0704: 'Batch Location Data Send',
    0x8300: 'Platform Issues Commands',
    0x0900: 'Device Answer'
};

function parseMessage(buffer) {
    // Remove characteristic bytes and handle escape sequences
    buffer = handleEscapeSequences(buffer);

    // Verify checksum
    if (!verifyChecksum(buffer)) {
        throw new Error('Invalid checksum');
    }

    // Parse message header
    const messageId = buffer.readUInt16BE(1);
    const messageBodyLength = buffer.readUInt16BE(3) & 0x03FF;
    const phoneNumber = buffer.slice(5, 11).toString('hex');
    const messageSerialNumber = buffer.readUInt16BE(11);

    // Parse message body based on message ID
    const messageBody = buffer.slice(13, 13 + messageBodyLength);
    const parsedBody = parseMessageBody(messageId, messageBody);

    return {
        messageId,
        messageType: MESSAGE_TYPES[messageId] || 'Unknown',
        phoneNumber,
        messageSerialNumber,
        messageBody: parsedBody
    };
}

function handleEscapeSequences(buffer) {
    let result = [];
    for (let i = 0; i < buffer.length; i++) {
        if (buffer[i] === 0x7d) {
            if (buffer[i + 1] === 0x02) {
                result.push(0x7e);
                i++;
            } else if (buffer[i + 1] === 0x01) {
                result.push(0x7d);
                i++;
            }
        } else {
            result.push(buffer[i]);
        }
    }
    return Buffer.from(result);
}

function verifyChecksum(buffer) {
    let checksum = 0;
    for (let i = 1; i < buffer.length - 2; i++) {
        checksum ^= buffer[i];
    }
    return checksum === buffer[buffer.length - 2];
}

function parseMessageBody(messageId, buffer) {
    switch (messageId) {
        case 0x0001:
            return parseGeneralResponse(buffer);
        case 0x0100:
            return parseTerminalRegister(buffer);
        case 0x8100:
            return parseTerminalRegisterResponse(buffer);
        case 0x0102:
            return parseTerminalAuthentication(buffer);
        case 0x8001:
            return parsePlatformGeneralResponse(buffer);
        case 0x0200:
            return parseLocationInformationReport(buffer);
        case 0x0704:
            return parseBatchLocationDataSend(buffer);
        case 0x8300:
            return parsePlatformIssuesCommands(buffer);
        case 0x0900:
            return parseDeviceAnswer(buffer);
        default:
            return buffer.toString('hex');
    }
}

function parseGeneralResponse(buffer) {
    return {
        responseSerialNumber: buffer.readUInt16BE(0),
        responseId: buffer.readUInt16BE(2),
        result: buffer.readUInt8(4)
    };
}

function parseTerminalRegister(buffer) {
    return {
        provinceId: buffer.readUInt16BE(0),
        countryId: buffer.readUInt16BE(2),
        manufacturerId: buffer.slice(4, 9).toString('hex'),
        terminalType: buffer.slice(9, 29).toString('hex'),
        terminalId: buffer.slice(29, 36).toString('hex'),
        plateColor: buffer.readUInt8(36),
        plateNo: buffer.slice(37).toString('utf8')
    };
}

function parseTerminalRegisterResponse(buffer) {
    return {
        responseSerialNumber: buffer.readUInt16BE(0),
        result: buffer.readUInt8(2),
        authenticationKey: buffer.slice(3).toString('utf8')
    };
}

function parseTerminalAuthentication(buffer) {
    return {
        authenticationKey: buffer.toString('utf8')
    };
}

function parsePlatformGeneralResponse(buffer) {
    return {
        responseSerialNumber: buffer.readUInt16BE(0),
        responseId: buffer.readUInt16BE(2),
        result: buffer.readUInt8(4)
    };
}

function parseLocationInformationReport(buffer) {
    return {
        alarm: buffer.readUInt32BE(0),
        state: parseState(buffer.readUInt32BE(4)),
        latitude: buffer.readUInt32BE(8) / 1000000,
        longitude: buffer.readUInt32BE(12) / 1000000,
        altitude: buffer.readUInt16BE(16),
        speed: buffer.readUInt16BE(18) / 10,
        direction: buffer.readUInt16BE(20),
        time: parseBCDTime(buffer.slice(22, 28)),
        additionalInfo: parseAdditionalInfo(buffer.slice(28))
    };
}

function parseState(state) {
    return {
        acc: (state & 0x01) !== 0,
        positioning: (state & 0x02) !== 0,
        latitude: (state & 0x04) !== 0 ? 'south' : 'north',
        longitude: (state & 0x08) !== 0 ? 'west' : 'east',
        operationState: (state & 0x10) !== 0,
        encryption: (state & 0x20) !== 0,
        fuelCircuit: (state & 0x400) !== 0,
        circuit: (state & 0x800) !== 0,
        doorLock: (state & 0x1000) !== 0
    };
}

function parseBCDTime(buffer) {
    const year = buffer.readUInt8(0).toString(16).padStart(2, '0');
    const month = buffer.readUInt8(1).toString(16).padStart(2, '0');
    const day = buffer.readUInt8(2).toString(16).padStart(2, '0');
    const hour = buffer.readUInt8(3).toString(16).padStart(2, '0');
    const minute = buffer.readUInt8(4).toString(16).padStart(2, '0');
    const second = buffer.readUInt8(5).toString(16).padStart(2, '0');
    return `20${year}-${month}-${day} ${hour}:${minute}:${second}`;
}

function parseAdditionalInfo(buffer) {
    let additionalInfo = {};
    let offset = 0;
    while (offset < buffer.length) {
        const id = buffer.readUInt8(offset);
        const length = buffer.readUInt8(offset + 1);
        const value = buffer.slice(offset + 2, offset + 2 + length);
        additionalInfo[id] = parseAdditionalInfoValue(id, value);
        offset += 2 + length;
    }
    return additionalInfo;
}

function parseAdditionalInfoValue(id, buffer) {
    switch (id) {
        case 0x01:
            return buffer.readUInt32BE(0) / 10; // Mileage
        case 0x02:
            return buffer.readUInt16BE(0) / 10; // Fuel capacity
        case 0x03:
            return buffer.readUInt16BE(0) / 10; // Speed
        case 0x25:
            return buffer.readUInt32BE(0); // Extended Vehicle Signal Status Bits
        case 0x30:
            return buffer.readUInt8(0); // GSM Signal
        case 0x31:
            return buffer.readUInt8(0); // GNSS satellites Numbers
        case 0xD5:
            return parseLockData(buffer); // A1L lock data information
        case 0xE3:
            return buffer.readUInt8(0) === 1; // Low voltage sign
        case 0xE5:
            return buffer.readUInt32BE(0); // Statistics of the number of read and write errors in the blind zone data
        case 0xE7:
            return buffer.readUInt16BE(0); // Main battery voltage value
        case 0xE8:
            return buffer.readUInt16BE(0); // Backup voltage value
        case 0xE9:
            return buffer.readUInt32BE(0); // Test Data
        default:
            return buffer.toString('hex'); // Default to hex string
    }
}

function parseLockData(buffer) {
    const totalLocks = buffer.readUInt8(0);
    let locks = [];
    for (let i = 0; i < totalLocks; i++) {
        const offset = 1 + i * 13;
        locks.push({
            lockDevID: buffer.slice(offset, offset + 5).toString('hex'),
            cardID: buffer.slice(offset + 5, offset + 10).toString('hex'),
            lockPower: buffer.readUInt8(offset + 10),
            lockStatus: parseLockStatus(buffer.readUInt16BE(offset + 11))
        });
    }
    return locks;
}

function parseLockStatus(status) {
    return {
        sealTempered: (status & 0x01) !== 0,
        lockRope: (status & 0x02) !== 0,
        timeOut: (status & 0x04) !== 0,
        coverStatus: (status & 0x08) !== 0,
        unCoverBack: (status & 0x10) !== 0,
        lockOpen: (status & 0x20) !== 0,
        lockCutOff: (status & 0x40) !== 0,
        lockStuck: (status & 0x80) !== 0,
        lowPower: (status & 0x100) !== 0,
        illegalCard: (status & 0x200) !== 0
    };
}

function parseBatchLocationDataSend(buffer) {
    const numberOfDataItems = buffer.readUInt16BE(0);
    const locationDataType = buffer.readUInt8(2);
    const locationReportDataLength = buffer.readUInt16BE(3);
    const locationReportData = buffer.slice(5, 5 + locationReportDataLength);

    return {
        numberOfDataItems,
        locationDataType,
        locationReportData: parseLocationInformationReport(locationReportData)
    };
}

function parsePlatformIssuesCommands(buffer) {
    return {
        flag: buffer.readUInt8(0),
        textMessage: buffer.slice(1).toString('utf8')
    };
}

function parseDeviceAnswer(buffer) {
    return {
        transparentMessageType: buffer.readUInt8(0),
        transparentMessageContent: buffer.slice(1).toString('utf8')
    };
}

// 示例用法
const exampleBuffer = Buffer.from('7E0100002B001234567890003600000000FFFFFFFFFF48422D654C4F434B2D3942484741330000000032333431333133024142433132335E7E', 'hex');
const parsedMessage = parseMessage(exampleBuffer);
console.log(parsedMessage);

app.post('/api/messages', (req, res) => {
    try {
        const parsedMessage = parseMessage(req.body);
        res.status(200).json(parsedMessage);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});