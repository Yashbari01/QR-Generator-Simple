import React from 'react';
import { FaGithub, FaBriefcase, FaHeart, FaLinkedin, FaEnvelope } from 'react-icons/fa';

const Footer = () => {
  const socialLinks = [
    {
      icon: <FaGithub />,
      href: "https://github.com/Yashbari01",
      label: "GitHub",
    },
    {
      icon: <FaLinkedin />,
      href: "https://in.linkedin.com/in/yash-bari-143467216",
      label: "LinkedIn",
    },
    {
      icon: <FaBriefcase />,
      href: "https://yashbariportfolio.netlify.app/",
      label: "Portfolio",
    },
    {
      icon: <FaEnvelope />,
      href: "mailto:your.email@example.com",
      label: "Email",
    },
  ];

  return (
    <footer className="relative w-full bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900">
      {/* Animated gradient border */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 animate-gradient-x"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Footer Content */}
        {/* <div className="grid grid-cols-1 lg:grid-cols-2 gap-12"> */}
        <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
          {/* Brand Section */}
          <div className="space-y-4">
            <h3 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text inline-block">
              QR Code Generator
            </h3>
            <p className="text-gray-400 text-sm leading-relaxed max-w-md">
              Create beautiful custom QR codes for your business or personal use. 
              Simple, fast, and professional-grade QR codes in seconds.
            </p>
          </div>

          {/* Quick Links */}
          {/* <div className="space-y-4">
            <h4 className="text-white text-lg font-semibold">Quick Links</h4>
            <ul className="space-y-2">
              {['Home', 'Features', 'About', 'Contact'].map((item) => (
                <li key={item}>
                  <a 
                    href={`#${item.toLowerCase()}`}
                    className="text-gray-400 hover:text-white transition-colors duration-300 text-sm block"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div> */}

          {/* Social Links */}
          <div className="space-y-4">
            <h4 className="text-white text-lg font-semibold">Connect With Me</h4>
            <div className="flex flex-wrap gap-4">
              {socialLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transform hover:scale-110 transition-all duration-300 p-2 bg-gray-800 rounded-lg hover:bg-gray-700"
                  aria-label={link.label}
                >
                  <span className="text-xl">{link.icon}</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-gray-700">
          <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
            <div className="text-gray-400 text-sm">
              &copy; {new Date().getFullYear()} QR Code Generator. All rights reserved.
            </div>
            
            <div className="flex items-center text-gray-400 text-sm group">
              <span>Made with</span>
              <FaHeart className="mx-2 text-red-500 animate-pulse group-hover:scale-110 transition-transform duration-300" />
              <span>by</span>
              <a
                href="https://yashbariportfolio.netlify.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="ml-2 text-white hover:text-blue-400 transition-colors duration-300 font-medium"
              >
                Yash Bari
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;