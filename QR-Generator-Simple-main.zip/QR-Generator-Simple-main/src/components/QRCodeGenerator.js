// // src/components/QRCodeGenerator.js
// import React, { useState, useRef } from 'react';
// import { FaDownload, FaQrcode, FaUpload } from 'react-icons/fa';
// import { MdColorLens } from 'react-icons/md';
// import QRCode from 'qrcode';

// const QRCodeGenerator = () => {
//   const [inputText, setInputText] = useState('');
//   const [foregroundColor, setForegroundColor] = useState('#000000');
//   const [backgroundColor, setBackgroundColor] = useState('#ffffff');
//   const [logo, setLogo] = useState(null);
//   const canvasRef = useRef(null);

//   const handleInputChange = (e) => {
//     setInputText(e.target.value);
//   };

//   const handleColorChange = (e) => {
//     const { name, value } = e.target;
//     if (name === 'foreground') {
//       setForegroundColor(value);
//     } else {
//       setBackgroundColor(value);
//     }
//   };

//   const handleLogoUpload = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       const reader = new FileReader();
//       reader.onloadend = () => {
//         setLogo(reader.result);
//       };
//       reader.readAsDataURL(file);
//     }
//   };

//   const generateQRCode = () => {
//     if (inputText.trim() === '') {
//       alert('Please enter some text to generate the QR code.');
//       return;
//     }

//     const options = {
//       width: 256,
//       color: {
//         dark: foregroundColor,
//         light: backgroundColor,
//       },
//     };

//     QRCode.toCanvas(canvasRef.current, inputText, options, (error) => {
//       if (error) {
//         console.error(error);
//       } else {
//         if (logo) {
//           const canvas = canvasRef.current;
//           const ctx = canvas.getContext('2d');
//           const logoImg = new Image();
//           logoImg.src = logo;
//           logoImg.onload = () => {
//             const logoSize = 64;
//             const x = (canvas.width - logoSize) / 2;
//             const y = (canvas.height - logoSize) / 2;
//             ctx.drawImage(logoImg, x, y, logoSize, logoSize);
//           };
//         }
//       }
//     });
//   };

//   const downloadQRCode = () => {
//     if (!canvasRef.current) return;

//     const dataURL = canvasRef.current.toDataURL('image/png');

//     const a = document.createElement('a');
//     a.href = dataURL;
//     a.download = 'qrcode.png';
//     a.click();
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 p-4 sm:p-6 md:p-8">
//       <div className="max-w-4xl mx-auto">
//         <div className="bg-white backdrop-blur-lg bg-opacity-90 rounded-2xl shadow-xl p-6 sm:p-8">
//           <div className="text-center mb-8">
//             <div className="flex items-center justify-center mb-4">
//               <FaQrcode className="text-4xl text-indigo-600" />
//             </div>
//             <h1 className="text-3xl font-bold text-gray-800 mb-2">QR Code Generator</h1>
//             <p className="text-gray-600">Create custom QR codes with your brand colors and logo</p>
//           </div>

//           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
//             <div className="space-y-6">
//               <div className="space-y-2">
//                 <label className="text-sm font-medium text-gray-700">Content</label>
//                 <input
//                   type="text"
//                   value={inputText}
//                   onChange={handleInputChange}
//                   placeholder="Enter URL or text"
//                   className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition duration-200"
//                 />
//               </div>

//               <div className="grid grid-cols-2 gap-4">
//                 <div className="space-y-2">
//                   <label className="flex items-center text-sm font-medium text-gray-700">
//                     <MdColorLens className="mr-2" />
//                     Foreground
//                   </label>
//                   <div className="flex items-center space-x-2">
//                     <input
//                       type="color"
//                       name="foreground"
//                       value={foregroundColor}
//                       onChange={handleColorChange}
//                       className="w-12 h-12 rounded-lg cursor-pointer border-0"
//                     />
//                     <span className="text-sm text-gray-600">{foregroundColor}</span>
//                   </div>
//                 </div>

//                 <div className="space-y-2">
//                   <label className="flex items-center text-sm font-medium text-gray-700">
//                     <MdColorLens className="mr-2" />
//                     Background
//                   </label>
//                   <div className="flex items-center space-x-2">
//                     <input
//                       type="color"
//                       name="background"
//                       value={backgroundColor}
//                       onChange={handleColorChange}
//                       className="w-12 h-12 rounded-lg cursor-pointer border-0"
//                     />
//                     <span className="text-sm text-gray-600">{backgroundColor}</span>
//                   </div>
//                 </div>
//               </div>

//               <div className="space-y-2">
//                 <label className="flex items-center text-sm font-medium text-gray-700">
//                   <FaUpload className="mr-2" />
//                   Upload Logo
//                 </label>
//                 <div className="flex items-center justify-center w-full">
//                   <label className="w-full flex flex-col items-center px-4 py-6 bg-white rounded-lg shadow-lg tracking-wide border border-gray-200 cursor-pointer hover:bg-gray-50 transition duration-200">
//                     <FaUpload className="text-indigo-500 text-2xl" />
//                     <span className="mt-2 text-sm text-gray-600">Select your logo</span>
//                     <input
//                       type="file"
//                       onChange={handleLogoUpload}
//                       accept="image/*"
//                       className="hidden"
//                     />
//                   </label>
//                 </div>
//               </div>

//               <button
//                 onClick={generateQRCode}
//                 className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg shadow-md hover:shadow-lg transition duration-200 flex items-center justify-center space-x-2"
//               >
//                 <FaQrcode />
//                 <span>Generate QR Code</span>
//               </button>
//             </div>

//             <div className="flex flex-col items-center justify-center space-y-6">
//               <div className="bg-white p-4 rounded-xl shadow-md">
//                 <canvas ref={canvasRef} className="max-w-full" />
//               </div>

//               <button
//                 onClick={downloadQRCode}
//                 className="py-3 px-6 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg shadow-md hover:shadow-lg transition duration-200 flex items-center space-x-2"
//               >
//                 <FaDownload />
//                 <span>Download QR Code</span>
//               </button>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default QRCodeGenerator;

import React, { useState, useRef } from 'react';
import { FaDownload, FaQrcode, FaUpload } from 'react-icons/fa';
import { MdColorLens } from 'react-icons/md';
import QRCode from 'qrcode';

const QRCodeGenerator = () => {
  const [inputText, setInputText] = useState('');
  const [foregroundColor, setForegroundColor] = useState('#000000');
  const [backgroundColor, setBackgroundColor] = useState('#ffffff');
  const [logo, setLogo] = useState(null);
  const [errorCorrection, setErrorCorrection] = useState('L');
  const [qrSize, setQrSize] = useState(256);
  const [borderWidth, setBorderWidth] = useState(4);
  const [downloadFormat, setDownloadFormat] = useState('png');
  const [qrCodeType, setQrCodeType] = useState('url');
  const [email, setEmail] = useState({ to: '', subject: '', body: '' });
  const [wifi, setWifi] = useState({ ssid: '', password: '', hidden: false });
  const [event, setEvent] = useState({ title: '', start: '', end: '', location: '', description: '' });
  const canvasRef = useRef(null);

  const handleInputChange = (e) => {
    setInputText(e.target.value);
  };

  const handleColorChange = (e) => {
    const { name, value } = e.target;
    if (name === 'foreground') {
      setForegroundColor(value);
    } else {
      setBackgroundColor(value);
    }
  };

  const handleLogoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogo(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleErrorCorrectionChange = (e) => {
    setErrorCorrection(e.target.value);
  };

  const handleSizeChange = (e) => {
    setQrSize(e.target.value);
  };

  const handleBorderWidthChange = (e) => {
    setBorderWidth(e.target.value);
  };

  const handleDownloadFormatChange = (e) => {
    setDownloadFormat(e.target.value);
  };

  const handleQRCodeTypeChange = (e) => {
    setQrCodeType(e.target.value);
  };

  const handleEmailChange = (e) => {
    const { name, value } = e.target;
    setEmail((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleWifiChange = (e) => {
    const { name, value, type, checked } = e.target;
    setWifi((prevState) => ({
      ...prevState,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleEventChange = (e) => {
    const { name, value } = e.target;
    setEvent((prevState) => ({ ...prevState, [name]: value }));
  };

  const generateQRCode = () => {
    let data = '';

    // Determine the QR code data based on the selected type
    switch (qrCodeType) {
      case 'url':
        data = inputText;
        break;
      case 'text':
        data = inputText;
        break;
      case 'email':
        data = `mailto:${email.to}?subject=${email.subject}&body=${email.body}`;
        break;
      case 'wifi':
        data = `WIFI:S:${wifi.ssid};T:${wifi.hidden ? 'WPA' : 'WEP'};P:${wifi.password};;`;
        break;
      case 'event':
        const { title, start, end, location, description } = event;
        data = `BEGIN:VEVENT\nSUMMARY:${title}\nDTSTART:${start}\nDTEND:${end}\nLOCATION:${location}\nDESCRIPTION:${description}\nEND:VEVENT`;
        break;
      case 'vcard':
        data = `BEGIN:VCARD\nVERSION:3.0\nFN:${inputText}\nTEL:${inputText}\nEND:VCARD`;
        break;
      default:
        data = inputText;
        break;
    }

    // If data is empty after determining the type, alert the user
    if (data.trim() === '') {
      alert('Please fill in the required fields.');
      return;
    }

    // QR code generation options
    const options = {
      width: qrSize,
      color: {
        dark: foregroundColor,
        light: backgroundColor,
      },
      errorCorrectionLevel: errorCorrection,
      margin: borderWidth,
    };

    // Generate QR code to canvas
    QRCode.toCanvas(canvasRef.current, data, options, (error) => {
      if (error) {
        console.error(error);
      } else {
        // If logo is provided, add it to the QR code
        if (logo) {
          const canvas = canvasRef.current;
          const ctx = canvas.getContext('2d');
          const logoImg = new Image();
          logoImg.src = logo;
          logoImg.onload = () => {
            const logoSize = qrSize / 5; // Size relative to QR code size
            const x = (canvas.width - logoSize) / 2;
            const y = (canvas.height - logoSize) / 2;
            ctx.drawImage(logoImg, x, y, logoSize, logoSize);
          };
        }
      }
    });
  };

  const downloadQRCode = () => {
    if (!canvasRef.current) return;

    const dataURL = canvasRef.current.toDataURL(`image/${downloadFormat}`);

    const a = document.createElement('a');
    a.href = dataURL;
    a.download = `qrcode.${downloadFormat}`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 p-4 sm:p-6 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white backdrop-blur-lg bg-opacity-90 rounded-2xl shadow-xl p-4 sm:p-6 md:p-8 transition-all duration-300 hover:shadow-2xl">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <FaQrcode className="text-4xl text-indigo-600 animate-pulse" />
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-800 mb-2">
              QR Code Generator
            </h1>
            <p className="text-sm sm:text-base text-gray-600 max-w-md mx-auto">
              Create custom QR codes with your brand colors and logo
            </p>
          </div>
          <div className="bg-white backdrop-blur-lg bg-opacity-90 rounded-2xl shadow-xl p-4 sm:p-6 md:p-8 transition-all duration-300">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                {/* QR Code Type Selection */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 block">QR Code Type</label>
                    <select
                      value={qrCodeType}
                      onChange={handleQRCodeTypeChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition duration-200"
                    >
                      <option value="url">URL</option>
                      <option value="text">Text</option>
                      <option value="email">Email</option>
                      <option value="vcard">vCard</option>
                      <option value="wifi">Wi-Fi</option>
                      <option value="event">Event</option>
                    </select>
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  {qrCodeType === 'url' || qrCodeType === 'text' ? (
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700 block">Content</label>
                      <input
                        type="text"
                        value={inputText}
                        onChange={handleInputChange}
                        placeholder={qrCodeType === 'url' ? "Enter URL" : "Enter Text"}
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                    </div>
                  ) : qrCodeType === 'email' ? (
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700 block">Email Details</label>
                      <input
                        type="email"
                        name="to"
                        value={email.to}
                        onChange={handleEmailChange}
                        placeholder="Recipient Email"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                      <input
                        type="text"
                        name="subject"
                        value={email.subject}
                        onChange={handleEmailChange}
                        placeholder="Subject"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                      <textarea
                        name="body"
                        value={email.body}
                        onChange={handleEmailChange}
                        placeholder="Body"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                    </div>
                  ) : qrCodeType === 'wifi' ? (
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700 block">Wi-Fi Details</label>
                      <input
                        type="text"
                        name="ssid"
                        value={wifi.ssid}
                        onChange={handleWifiChange}
                        placeholder="SSID"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                      <input
                        type="password"
                        name="password"
                        value={wifi.password}
                        onChange={handleWifiChange}
                        placeholder="Password"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                      <label className="flex items-center text-sm font-medium text-gray-700">
                        <input
                          type="checkbox"
                          name="hidden"
                          checked={wifi.hidden}
                          onChange={handleWifiChange}
                          className="mr-2"
                        />
                        Hidden Network
                      </label>
                    </div>
                  ) : qrCodeType === 'event' ? (
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700 block">Event Details</label>
                      <input
                        type="text"
                        name="title"
                        value={event.title}
                        onChange={handleEventChange}
                        placeholder="Event Title"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                      <input
                        type="datetime-local"
                        name="start"
                        value={event.start}
                        onChange={handleEventChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                      <input
                        type="datetime-local"
                        name="end"
                        value={event.end}
                        onChange={handleEventChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                      <input
                        type="text"
                        name="location"
                        value={event.location}
                        onChange={handleEventChange}
                        placeholder="Location"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                      <textarea
                        name="description"
                        value={event.description}
                        onChange={handleEventChange}
                        placeholder="Event Description"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                    </div>
                  ) : qrCodeType === 'vcard' ? (
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700 block">vCard Information</label>
                      <input
                        type="text"
                        value={inputText}
                        onChange={handleInputChange}
                        placeholder="Enter Name or Phone"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 transition-all duration-200"
                      />
                    </div>
                  ) : null}
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="flex items-center text-sm font-medium text-gray-700">
                        <MdColorLens className="mr-2 text-indigo-600" />
                        Foreground
                      </label>
                      <div className="flex items-center space-x-2">
                        <input
                          type="color"
                          name="foreground"
                          value={foregroundColor}
                          onChange={handleColorChange}
                          className="w-12 h-12 rounded-lg cursor-pointer border-0 shadow-sm"
                        />
                        <span className="text-sm text-gray-600">{foregroundColor}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="flex items-center text-sm font-medium text-gray-700">
                        <MdColorLens className="mr-2 text-indigo-600" />
                        Background
                      </label>
                      <div className="flex items-center space-x-2">
                        <input
                          type="color"
                          name="background"
                          value={backgroundColor}
                          onChange={handleColorChange}
                          className="w-12 h-12 rounded-lg cursor-pointer border-0 shadow-sm"
                        />
                        <span className="text-sm text-gray-600">{backgroundColor}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Upload Logo (optional)
                  </label>
                  <div className="flex items-center justify-center w-full">
                    <label className="w-full flex flex-col items-center px-4 py-6 bg-white rounded-lg border-2 border-dashed border-gray-300 cursor-pointer hover:border-indigo-500 transition-all duration-200">
                      <FaUpload className="text-gray-400 text-2xl mb-2" />
                      <span className="text-sm text-gray-500">Click to upload</span>
                      <input type="file" className="hidden" onChange={handleLogoUpload}
                        accept="image/*" />
                    </label>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-lg font-medium text-gray-800 mb-4">
                    Advanced Settings
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700 block">Error Correction Level</label>
                      <select
                        value={errorCorrection}
                        onChange={handleErrorCorrectionChange}
                        className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="L">Low (7%)</option>
                        <option value="M">Medium (15%)</option>
                        <option value="Q">Quartile (25%)</option>
                        <option value="H">High (30%)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700 block">Size</label>
                      <input
                        type="number"
                        value={qrSize}
                        onChange={handleSizeChange}
                        min="128"
                        max="1024"
                        className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700 block">Border Width</label>
                      <input
                        type="number"
                        value={borderWidth}
                        onChange={handleBorderWidthChange}
                        min="1"
                        max="10"
                        className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700 block">Download Format</label>
                      <select
                        value={downloadFormat}
                        onChange={handleDownloadFormatChange}
                        className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="png">PNG</option>
                        <option value="jpeg">JPEG</option>
                        <option value="svg">SVG</option>
                      </select>
                    </div>
                  </div>
                </div>

                <button
                  onClick={generateQRCode}
                  className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg shadow-md hover:shadow-lg transition duration-200 flex items-center justify-center space-x-2"
                >
                  <FaQrcode className="text-xl" />
                  <span>Generate QR Code</span>
                </button>
              </div>

              <div className="flex flex-col items-center justify-start space-y-6">
                <div className="bg-gray-50 p-6 rounded-xl shadow-md w-full max-w-md">
                  <div className="aspect-square relative">
                    <canvas
                      ref={canvasRef}
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>
                <button
                  onClick={downloadQRCode}
                  className="py-3 px-6 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg shadow-md hover:shadow-lg transition duration-200 flex items-center space-x-2"
                >
                  <FaDownload className="text-xl" />
                  <span>Download QR Code</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QRCodeGenerator;
